# D6 smoke observations

K=5, T=200, seeds=[0, 1]. Fixed SW window=200; D-UCB gamma=0.995.

| Scenario | Instance | Final dynamic regret (mean +/- SEM) |
|---|---|---:|
| stationary | random | 43.450 +/- 0.250 |
| stationary | ucb1 | 28.700 +/- 2.500 |
| stationary | sw_w200 | 28.700 +/- 2.500 |
| stationary | du_g0995 | 36.400 +/- 0.500 |
| piecewise | random | 55.050 +/- 3.450 |
| piecewise | ucb1 | 36.300 +/- 10.300 |
| piecewise | sw_w200 | 36.300 +/- 10.300 |
| piecewise | du_g0995 | 44.900 +/- 1.000 |
| drift | random | 41.123 +/- 2.826 |
| drift | ucb1 | 27.716 +/- 0.566 |
| drift | sw_w200 | 27.716 +/- 0.566 |
| drift | du_g0995 | 33.887 +/- 0.060 |

## Switch diagnostics (arm 4; zero-based delay after change)

| Instance | Median pre-change gap | Revisited / seeds | Median delay among revisits |
|---|---:|---:|---:|
| random | 0.5 | 2 / 2 | 5.5 |
| ucb1 | 3.0 | 2 / 2 | 23.0 |
| sw_w200 | 3.0 | 2 / 2 | 23.0 |
| du_g0995 | 3.0 | 2 / 2 | 4.5 |

A delay of 0 means arm 4 was selected on the change round. Missing delays are
right-censored, not zero; the conditional median excludes those seeds.
Pre-change gaps count consecutive rounds without arm 4 immediately before the change.
If it was never selected, that gap is left-censored; see the per-seed CSV flags.

## Interpretation to complete

- Stationary: quantify the exploration cost of forgetting using the table and local curves.
- Piecewise: compare pre-change gaps, first revisits and regret over the first 200 post-change rounds.
  A first revisit alone does not establish sustained recovery; inspect actions and local regret.
- Drift: compare regret around the crossing and toward the end.
- Record any result contrary to expectations without retuning this run.

## Definitions and limits

Dynamic pseudo-regret at t is max_a mu[t,a] - mu[t,action[t]].
Local regret is its trailing 200-round mean, using available rounds at startup.
SEM uses the sample SD across seeds divided by sqrt(number of seeds); it is not a 95% CI.
The same numeric seeds do not imply an arm-indexed common reward table across policies.
Window size 200 and asymptotic discounted count 1/(1-0.995)=200 are only a scale match.
The two policies also have different confidence constants; this is not a controlled ablation.
Ten seeds and three prescribed environments do not establish universal algorithm rankings.
Smoke runs establish correctness only. Full experiments are not replayed by this script.
Passing this script does not automatically complete interpretation or tag a release.
