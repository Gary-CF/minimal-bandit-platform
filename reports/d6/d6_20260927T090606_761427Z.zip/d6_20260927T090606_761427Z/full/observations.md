# D6 full observations

K=5, T=5000, seeds=[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]. Fixed SW window=200; D-UCB gamma=0.995.

| Scenario | Instance | Final dynamic regret (mean +/- SEM) |
|---|---|---:|
| stationary | random | 1105.990 +/- 4.591 |
| stationary | ucb1 | 172.940 +/- 7.404 |
| stationary | sw_w200 | 660.790 +/- 5.000 |
| stationary | du_g0995 | 849.380 +/- 3.455 |
| piecewise | random | 1447.830 +/- 2.420 |
| piecewise | ucb1 | 211.900 +/- 14.107 |
| piecewise | sw_w200 | 756.720 +/- 4.055 |
| piecewise | du_g0995 | 1082.070 +/- 3.345 |
| drift | random | 1004.969 +/- 2.334 |
| drift | ucb1 | 204.039 +/- 6.905 |
| drift | sw_w200 | 568.048 +/- 5.437 |
| drift | du_g0995 | 763.280 +/- 2.220 |

## Switch diagnostics (arm 4; zero-based delay after change)

| Instance | Median pre-change gap | Revisited / seeds | Median delay among revisits |
|---|---:|---:|---:|
| random | 3.5 | 10 / 10 | 4.0 |
| ucb1 | 51.5 | 10 / 10 | 233.0 |
| sw_w200 | 9.5 | 10 / 10 | 7.5 |
| du_g0995 | 3.0 | 10 / 10 | 5.0 |

A delay of 0 means arm 4 was selected on the change round. Missing delays are
right-censored, not zero; the conditional median excludes those seeds.
Pre-change gaps count consecutive rounds without arm 4 immediately before the change.
If it was never selected, that gap is left-censored; see the per-seed CSV flags.

## Interpretation to complete

- Stationary: quantify the exploration cost of forgetting using the table and local curves.
- Piecewise: compare pre-change gaps, first revisits and regret over the first 200 post-change rounds.
  A first revisit alone does not establish sustained recovery; inspect actions and local regret.
- Drift: compare regret around the crossing and toward the end.
- Record any result contrary to expectations without retuning this run.

## Definitions and limits

Dynamic pseudo-regret at t is max_a mu[t,a] - mu[t,action[t]].
Local regret is its trailing 200-round mean, using available rounds at startup.
SEM uses the sample SD across seeds divided by sqrt(number of seeds); it is not a 95% CI.
The same numeric seeds do not imply an arm-indexed common reward table across policies.
Window size 200 and asymptotic discounted count 1/(1-0.995)=200 are only a scale match.
The two policies also have different confidence constants; this is not a controlled ablation.
Ten seeds and three prescribed environments do not establish universal algorithm rankings.
Smoke runs establish correctness only. Full experiments are not replayed by this script.
Passing this script does not automatically complete interpretation or tag a release.
