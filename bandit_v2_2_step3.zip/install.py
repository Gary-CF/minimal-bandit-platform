"""Install this lesson from the repository root; --check prints changes only."""
import argparse
from datetime import datetime
import hashlib
import json
from pathlib import Path
import shutil


def digest(data):
    return hashlib.sha256(data.replace(b'\r\n', b'\n')).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    repo = args.repo.resolve()
    package = Path(__file__).resolve().parent
    manifest = json.loads((package / 'install_manifest.json').read_text(encoding='utf-8'))
    if not (repo / 'envs/logistic_bandit.py').is_file():
        raise SystemExit('Run this command from the Bandit repository root.')
    for name, expected in manifest['prerequisites'].items():
        p = repo / name
        if not p.is_file() or digest(p.read_bytes()) != expected:
            raise SystemExit(f'Prerequisite differs or is missing: {name}. Keep your files and share this message.')
    changes = []
    for name, spec in manifest['files'].items():
        target = repo / name
        if not target.resolve().is_relative_to(repo) or target.is_symlink():
            raise SystemExit(f'Unexpected target: {name}')
        source = package / 'payload' / name
        new = source.read_bytes()
        if digest(new) != spec['new_sha256']:
            raise SystemExit(f'Package hash mismatch: {name}')
        if target.exists():
            old = target.read_bytes()
            if digest(old) == spec['new_sha256']:
                continue
            if spec['old_sha256'] is None or digest(old) != spec['old_sha256']:
                raise SystemExit(f'Local edits detected: {name}. No files were changed; share this message.')
        else:
            old = None
            if spec['old_sha256'] is not None:
                raise SystemExit(f'Previous lesson is missing: {name}. No files were changed.')
        changes.append((name, target, source, old))
    for name, target, source, old in changes:
        print(('ADD    ' if old is None else 'UPDATE ') + name)
    if args.check:
        print(f'CHECK PASS: {len(changes)} planned changes')
        return
    if not changes:
        print('INSTALL PASS: already installed')
        return
    backup = repo / 'artifacts' / ('v2_2_step3_backup_' + datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    for name, target, source, old in changes:
        if old is not None:
            dest = backup / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(old)
    applied = []
    try:
        for name, target, source, old in changes:
            target.parent.mkdir(parents=True, exist_ok=True)
            applied.append((target, old))
            shutil.copyfile(source, target)
    except Exception:
        for target, old in reversed(applied):
            if old is None:
                target.unlink(missing_ok=True)
            else:
                target.write_bytes(old)
        raise
    print(f'INSTALL PASS: {len(changes)} files; previous code backed up at {backup}')


if __name__ == '__main__':
    main()
