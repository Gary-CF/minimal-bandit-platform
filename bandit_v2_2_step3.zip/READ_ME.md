# Bandit v2.2 — 配置、CSV、计时与绘图

前置：已完成上一轮适配器和统一 episode（533 项测试）。
在项目根目录执行 `python artifacts/v2_2_step3_install/install.py`，安装器会核对上一轮文件并备份被更新的代码。
实际安装 5 个文件：更新 scripts/logistic_benchmark.py；新增 scripts/run_logistic_benchmark.py、两个 configs/v2_2 配置和一份测试。
本包只含源代码和配置，不含助手机器的实验数据。原报告的修改不在安装目标中。

## 核心改动

run_episode 新增 on_step 回调与 collect_rows 参数。默认行为保持原样，返回可重放的逐轮数值列表。
当 on_step 不为空时，每完成一次更新，将本轮 row 与 timing 传给调用方。
实验入口使用 collect_rows=False，每轮缓冲写 CSV，避免再保留一份全部轨迹列表。

- trajectory CSV 只保存算法、种子、动作、奖励、遗憾和更新前预测。
- timing CSV 单独保存选臂、更新、诊断、环境、轨迹行写入时间。
- 回调不会将真实参数或未来信息传给策略。
- update 包含求解和投影时间。
- trajectory_write_seconds 只衡量轨迹 CSV 的缓冲行写入；不含 timing CSV 写入、控制台打印和最终 flush/close。
- episode_wall_seconds 覆盖 episode 初始化、交互、两份 CSV 的写入关闭和进度打印；不含绘图与源代码归档。

## 运行

```bash
python -m pytest -q
python -m scripts.run_logistic_benchmark --config configs/v2_2/smoke.json --output artifacts/v2_2_smoke_r1
python -m scripts.run_logistic_benchmark --output artifacts/v2_2_smoke_r1 --verify-only
python -m scripts.run_logistic_benchmark --config configs/v2_2/development.json --output artifacts/v2_2_dev_r1
python -m scripts.run_logistic_benchmark --output artifacts/v2_2_dev_r1 --verify-only
```

预期 542 项测试；smoke 为 30 条×200轮，development 为75条×1000轮。
输出目录必须不存在。重复实验请更换 r1 为 r2；已存在的目录不会被覆盖。
异常停止，保留已写入的逐轮数据、status.json 和 failure.txt。

## 输出与读取

- config.json：实际配置；features.npy、truth/*.npy：实际任务。
- episodes/*.csv：逐轮轨迹；timing/*.csv：逐轮耗时。
- summary.csv：每条轨迹最终遗憾、奖励与成本。
- aggregate.csv：各场景/算法跨种子遗憾均值与 SEM、平均每步选臂/更新成本。
- figures/regret.png：三个场景的累计动态伪遗憾。
- figures/prediction_rmse.png：更新前全臂概率 RMSE（目前仅 OMD 提供）。
- figures/cost.png：当前任务集合中的平均每步选臂与更新耗时。
- task_diagnostics.json：参数路径长度、最优臂变化次数、平均最优/次优 gap。
- git.json、versions.json、source_snapshot.zip、source_sha256.json：来源与环境。
- manifest.json：输出全集哈希；verify-only 核验保存数据与快照，不要求当前工作区仍与快照一致。

本轮是固定开发配置，不是调参后的测试集成绩。一个特征集合、五个奖励种子，阴影为 SEM 而非95%置信区间。
下一轮再冻结验证/测试拆分及候选配置，加入突变前后窗口分析，随后开始 DOMD。
